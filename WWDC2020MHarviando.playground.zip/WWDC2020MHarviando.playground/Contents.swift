// MARK: UIKit based playground for presenting basic Covid-19 Prevention Acts
import UIKit
import AVFoundation
import PlaygroundSupport

extension DispatchQueue {

    static func background(delay: Double = 0.0, background: (()->Void)? = nil, completion: (() -> Void)? = nil) {
        DispatchQueue.global(qos: .background).async {
            background?()
            if let completion = completion {
                DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: {
                    completion()
                })
            }
        }
    }

}

class MyViewController: UIViewController {
 
// MARK: VARIABLES
    var isAct1: Bool = false
    var isAct2: Bool = false
    var isAct3: Bool = false
    var isAct4: Bool = false
    
    var isComplete1: Bool = false
    var isComplete2: Bool = false
    var isFace2Pressed: Bool = false
    
// MARK: IMAGES AND BUTTONS
    var bgImage: UIImageView!
    var faceImage: UIButton!
    var titleImage: UIImageView!
    var completionImage: UIImageView!
    
//: Part one
    var rightHand: UIButton!
    var leftHand: UIButton!
    var handsMoved: Int = 0
    var imagePart1: UIImageView!
    var imageTip1: UIImageView!
//:Part two
    var imagePart2: UIImageView!
    var imageTip2: UIImageView!
    var imageMask: UIImageView!
    
//:Part three
    var imagePart3: UIImageView!
    var imageTip3: UIImageView!
    var rightHandWash: UIButton!
    var leftHandWash: UIButton!
    var imageBubble: UIImageView!
    
//: Part four
    var imagePart4: UIImageView!
    var imageTip4: UIImageView!
    var imageDistance: UIImageView!
    var imagePerson2: UIButton!
    
//:restart screen
    var imageWellDone: UIImageView!
    var startButton: UIButton!
    var restartButton: UIButton!

// MARK: SOUNDS
    var clickSoundAudio: AVAudioPlayer?
    var successSoundAudio: AVAudioPlayer?
    var winSoundAudio: AVAudioPlayer?
    var automaticallyWaitsToMinimizeStalling: Bool = false
    
    func playClickSound() {
        guard let url = Bundle.main.url(forResource: "click", withExtension: "mp3") else { return }

        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            clickSoundAudio = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
            
            guard let clickSoundPlayer = clickSoundAudio else { return }

            clickSoundPlayer.play()
            clickSoundPlayer.volume = 0.8 // Volume. Normal = 1

        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    func playSuccessSound() {
        guard let url = Bundle.main.url(forResource: "success", withExtension: "mp3") else { return }

        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            successSoundAudio = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
            
            guard let successSoundPlayer = successSoundAudio else { return }
            
            successSoundPlayer.play()
            successSoundPlayer.volume = 0.9 // Volume. Normal = 1

        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    func playWinSound() {
        guard let url = Bundle.main.url(forResource: "win", withExtension: "mp3") else { return }

        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            successSoundAudio = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
            
            guard let winSoundPlayer = successSoundAudio else { return }
            
            winSoundPlayer.play()
            winSoundPlayer.volume = 1.2 // Volume. Normal = 1

        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    override func loadView() {
        
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 640, height: 440))
        self.view = view
        
        bgImage = UIImageView(frame: CGRect(x: 0, y: 0, width: 640, height: 440))
        bgImage.image = UIImage(named: "mainBackground.png")
        view.addSubview(bgImage)
        
        completionImage = UIImageView(frame: CGRect(x: 240, y: 140, width: 160, height: 160))
        completionImage.image = UIImage(named: "completionImage.png")
        view.addSubview(completionImage)
        UIView.animate(withDuration: 0.1, animations: {
           self.completionImage.alpha = 0
        }, completion: nil)
        
        faceImage = UIButton(frame: CGRect(x: 240, y: 130, width: 160, height: 180))
        faceImage.setImage(UIImage(named: "face.png"), for: .normal)
        view.addSubview(faceImage)
        faceImage.addTarget(self, action: #selector(facePressed(_:)), for: .touchUpInside)
        
        titleImage = UIImageView(frame: CGRect(x: 46, y: 52, width: 549, height: 30))
        titleImage.image = UIImage(named: "imageTitle.png")
        view.addSubview(titleImage)
        
        startButton = UIButton(frame: CGRect(x: 257, y: 354, width: 127, height: 38))
        startButton.setImage(UIImage(named: "buttonStart.png"), for: .normal)
        
        view.addSubview(startButton)
        startButton.addTarget(self, action: #selector(startButtonPressed(_:)), for: .touchUpInside)
        
        rightHand = UIButton(frame: CGRect(x: 62, y: 205, width: 80, height: 172))
        rightHand.setImage(UIImage(named: "rightHand.png"), for: .normal)
        
        view.addSubview(rightHand)
        rightHand.addTarget(self, action: #selector(rightHandPressed(_:)), for: .touchUpInside)
        UIView.animate(withDuration: 0.1, animations: {
            self.rightHand.frame.origin.y += 250
        }, completion: nil)
        
        leftHand = UIButton(frame: CGRect(x: 143, y: 230, width: 80, height: 172))
        leftHand.setImage(UIImage(named: "leftHand.png"), for: .normal)
        
        view.addSubview(leftHand)
        leftHand.addTarget(self, action: #selector(leftHandPressed(_:)), for: .touchUpInside)
        UIView.animate(withDuration: 0.1, animations: {
            self.leftHand.frame.origin.y += 250
        }, completion: nil)
        
        imagePart1 = UIImageView(frame: CGRect(x: 36, y: 52, width: 569, height: 40))
        imagePart1.image = UIImage(named: "imagePart1.png")
        view.addSubview(imagePart1)
        UIView.animate(withDuration: 0.1, animations: {
            self.imagePart1.frame.origin.x -= 620
        }, completion: nil)
        
        imageTip1 = UIImageView(frame: CGRect(x: 250, y: 182, width: 358, height: 40))
        imageTip1.image = UIImage(named: "imageTip1.png")
        view.addSubview(imageTip1)
        UIView.animate(withDuration: 0.1, animations: {
            self.imageTip1.frame.origin.x += 420
        }, completion: nil)
        
        imagePart2 = UIImageView(frame: CGRect(x: 31, y: 52, width: 578, height: 40))
        imagePart2.image = UIImage(named: "imagePart2.png")
        view.addSubview(imagePart2)
        UIView.animate(withDuration: 0.1, animations: {
            self.imagePart2.frame.origin.x += 620
        }, completion: nil)
        
        imageTip2 = UIImageView(frame: CGRect(x: 185, y: 345, width: 271, height: 40))
        imageTip2.image = UIImage(named: "imageTip2.png")
        view.addSubview(imageTip2)
        UIView.animate(withDuration: 0.1, animations: {
            self.imageTip2.frame.origin.x -= 480
        }, completion: nil)
        
        imageMask = UIImageView(frame: CGRect(x: 253, y: 222, width: 134, height: 88))
        imageMask.image = UIImage(named: "imageMask.png")
        view.addSubview(imageMask)
        UIView.animate(withDuration: 0.1, animations: {
            self.imageMask.frame.origin.y += 250
        }, completion: nil)
        
        imagePart3 = UIImageView(frame: CGRect(x: 103, y: 52, width: 434, height: 40))
        imagePart3.image = UIImage(named: "imagePart3.png")
        view.addSubview(imagePart3)
        UIView.animate(withDuration: 0.1, animations: {
            self.imagePart3.frame.origin.y -= 100
        }, completion: nil)
        
        imageTip3 = UIImageView(frame: CGRect(x: 103, y: 130, width: 220, height: 40))
        imageTip3.image = UIImage(named: "imageTip3.png")
        view.addSubview(imageTip3)
        UIView.animate(withDuration: 0.1, animations: {
            self.imageTip3.frame.origin.y += 320
        }, completion: nil)
        
        rightHandWash = UIButton(frame: CGRect(x: 277, y: 302, width: 172, height: 62))
        rightHandWash.setImage(UIImage(named: "imageWHandRight.png"), for: .normal)
        
        view.addSubview(rightHandWash)
        rightHandWash.addTarget(self, action: #selector(handWashPressed(_:)), for: .touchUpInside)
        UIView.animate(withDuration: 0.1, animations: {
            self.rightHandWash.frame.origin.y += 150
        }, completion: nil)
        
        leftHandWash = UIButton(frame: CGRect(x: 259, y: 318, width: 172, height: 62))
        leftHandWash.setImage(UIImage(named: "imageWHandLeft.png"), for: .normal)
        
        view.addSubview(leftHandWash)
        leftHandWash.addTarget(self, action: #selector(handWashPressed(_:)), for: .touchUpInside)
        UIView.animate(withDuration: 0.1, animations: {
            self.leftHandWash.frame.origin.y += 150
        }, completion: nil)
        
        imageBubble = UIImageView(frame: CGRect(x: 233, y: 287, width: 109, height: 82))
        imageBubble.image = UIImage(named: "imageBubble.png")
        view.addSubview(imageBubble)
        UIView.animate(withDuration: 0.01, animations: {
            self.imageBubble.transform = CGAffineTransform(scaleX: 0, y: 0)
            self.imageBubble.alpha = 0
        }, completion: nil)
        
        imagePart4 = UIImageView(frame: CGRect(x: 75, y: 59, width: 490, height: 25))
        imagePart4.image = UIImage(named: "imagePart4.png")
        view.addSubview(imagePart4)
        UIView.animate(withDuration: 0.1, animations: {
            self.imagePart4.frame.origin.x += 570
        }, completion: nil)
        
        imageTip4 = UIImageView(frame: CGRect(x: 149, y: 355, width: 343, height: 40))
        imageTip4.image = UIImage(named: "imageTip4.png")
        view.addSubview(imageTip4)
        UIView.animate(withDuration: 0.1, animations: {
            self.imageTip4.frame.origin.x -= 500
        }, completion: nil)
        
        imagePerson2 = UIButton(frame: CGRect(x: 378, y: 130, width: 160, height: 180))
        imagePerson2.setImage(UIImage(named: "imagePerson2.png"), for: .normal)
        view.addSubview(imagePerson2)
        UIView.animate(withDuration: 0.1, animations: {
            self.imagePerson2.frame.origin.x += 300
        }, completion: nil)
        
        imageDistance = UIImageView(frame: CGRect(x: 149, y: 320, width: 344, height: 33))
        imageDistance.image = UIImage(named: "imageDistance.png")
        view.addSubview(imageDistance)
        UIView.animate(withDuration: 0.1, animations: {
            self.imageDistance.transform = CGAffineTransform(scaleX: 0, y: 0)
        }, completion: nil)
        
        restartButton = UIButton(frame: CGRect(x: 257, y: 354, width: 127, height: 38))
        restartButton.setImage(UIImage(named: "restartButton.png"), for: .normal)
        
        view.addSubview(restartButton)
        restartButton.addTarget(self, action: #selector(restartButtonPressed(_:)), for: .touchUpInside)
        UIView.animate(withDuration: 0.1, animations: {
            self.restartButton.transform = CGAffineTransform(scaleX: 0, y: 0)
        }, completion: nil)
        
        imageWellDone = UIImageView(frame: CGRect(x: 40, y: 46, width: 562, height: 56))
        imageWellDone.image = UIImage(named: "imageWellDone.png")
        view.addSubview(imageWellDone)
        UIView.animate(withDuration: 0.1, animations: {
            self.imageWellDone.transform = CGAffineTransform(scaleX: 0, y: 0)
        }, completion: nil)
        
        
    }
    @objc func startButtonPressed(_ sender: UIButton){
        DispatchQueue.background(background: {
            self.playClickSound()
        })
        actOne()
    }
    
    func actOne(){
        
        UIView.animate(withDuration: 1, animations: {
            self.titleImage.frame.origin.y -= 180
        }, completion: nil)
        
        UIView.animate(withDuration: 1, animations: {
            self.startButton.frame.origin.y += 180
        }, completion: {finished in
            DispatchQueue.background(background: {
                self.playSuccessSound()
            })
            UIView.animate(withDuration: 0.01, animations: {
                self.completionImage.transform = CGAffineTransform(scaleX: 0.5, y: 0.5)
                self.completionImage.alpha = 1
            }, completion: {finished in
                UIView.animate(withDuration: 0.5, animations: {
                    self.completionImage.transform = CGAffineTransform(scaleX: 2.7, y: 2.7)
                    self.completionImage.alpha = 0.1
                }, completion: {finished in
                    UIView.animate(withDuration: 0.01, animations: {
                        self.completionImage.transform = CGAffineTransform(scaleX: 1, y: 1)
                        self.completionImage.alpha = 0
                    }, completion: {finished in
                        
                        UIView.animate(withDuration: 1, animations: {
                            self.faceImage.frame.origin.x -= 180
                            self.completionImage.frame.origin.x -= 180/////////////
                        }, completion: {finished in
                            UIView.animate(withDuration: 1, delay: 1, animations: {
                                self.imagePart1.frame.origin.x += 620
                            }, completion: nil)
                            UIView.animate(withDuration: 1, delay: 1.3,animations: {
                                self.imageTip1.frame.origin.x -= 420
                            }, completion: nil)
                            
                            UIView.animate(withDuration: 1, animations: {
                            self.rightHand.frame.origin.y -= 250
                            }, completion: nil)
                            
                            UIView.animate(withDuration: 0.1, animations: {
                                self.imageTip1.frame.origin.x -= 1
                            }, completion: {finished in
                                UIView.animate(withDuration: 1, delay: 0.4,animations: {
                                self.leftHand.frame.origin.y -= 250
                                }, completion: nil)
                            })
                        })
                    })
                })
            })
            
            
            
        })
    }
    
    @objc func rightHandPressed(_ sender: UIButton){
        DispatchQueue.background(background: {
            self.playClickSound()
        })
        UIView.animate(withDuration: 1, animations: {
            self.rightHand.frame.origin.y += 250
        }, completion: { finished in
            self.handsMoved += 1
            self.allHandsMoved()
        })
    }
    
    @objc func leftHandPressed(_ sender: UIButton){
        DispatchQueue.background(background: {
            self.playClickSound()
        })
        UIView.animate(withDuration: 1, animations: {
            self.leftHand.frame.origin.y += 250
        }, completion: { finished in
            self.handsMoved += 1
            self.allHandsMoved()
        })
        
    }
    
    func allHandsMoved(){
        if handsMoved == 2{
            DispatchQueue.background(background: {
                self.playSuccessSound()
            })
            UIView.animate(withDuration: 0.01, animations: {
                self.completionImage.transform = CGAffineTransform(scaleX: 0.5, y: 0.5)
                self.completionImage.alpha = 1
            }, completion: {finished in
                UIView.animate(withDuration: 0.5, animations: {
                    self.completionImage.transform = CGAffineTransform(scaleX: 2.7, y: 2.7)
                    self.completionImage.alpha = 0.1
                }, completion: {finished in
                    UIView.animate(withDuration: 0.01, animations: {
                        self.completionImage.transform = CGAffineTransform(scaleX: 1, y: 1)
                        self.completionImage.alpha = 0
                    }, completion: {finished in
                        UIView.animate(withDuration: 1, animations: {
                            self.faceImage.frame.origin.x += 180
                            self.completionImage.frame.origin.x += 180
                        }, completion: {finished in
                            self.actTwo()
                        })
                        
                        UIView.animate(withDuration: 1,animations: {
                            self.imagePart1.frame.origin.x -= 620
                        }, completion: nil)
                        UIView.animate(withDuration: 1, animations: {
                            self.imageTip1.frame.origin.x += 420
                        }, completion: nil)
                        
                        self.handsMoved = 0
                            } //
                        )
                    }
                )}
            ) //
        }
    }
    
    func actTwo(){
        UIView.animate(withDuration: 1, animations: {
            self.imagePart2.frame.origin.x -= 620
        }, completion: nil)
        
        UIView.animate(withDuration: 1, animations: {
            self.imageTip2.frame.origin.x += 480
        }, completion: nil)
        
        isAct2 = true
    }
    
    @objc func facePressed(_ sender: UIButton){
        if isAct2 == true {
            DispatchQueue.background(background: {
                self.playClickSound()
            })
            UIView.animate(withDuration: 1, animations: {
                self.imageMask.frame.origin.y -= 250
            }, completion: { finised in
                
                DispatchQueue.background(background: {
                    self.playSuccessSound()
                })
                UIView.animate(withDuration: 0.01, animations: {
                    self.completionImage.transform = CGAffineTransform(scaleX: 0.5, y: 0.5)
                    self.completionImage.alpha = 1
                }, completion: {finished in
                    UIView.animate(withDuration: 0.5, animations: {
                        self.completionImage.transform = CGAffineTransform(scaleX: 2.7, y: 2.7)
                        self.completionImage.alpha = 0.1
                    }, completion: {finished in
                        UIView.animate(withDuration: 0.01, animations: {
                            self.completionImage.transform = CGAffineTransform(scaleX: 1, y: 1)
                            self.completionImage.alpha = 0
                        }, completion: {finished in
                                UIView.animate(withDuration: 1, delay: 0.5,animations: {
                                    self.imageTip2.frame.origin.x -= 480
                                }, completion: nil)
                                
                                UIView.animate(withDuration: 1.2, delay: 0.5, animations: {
                                    self.imagePart2.frame.origin.x += 620
                                }, completion: {finished in
                                    
                                    UIView.animate(withDuration: 1, animations: {
                                        self.imageMask.frame.origin.x += 137
                                    }, completion: nil)
                                    
                                    UIView.animate(withDuration: 1, animations: {
                                        self.faceImage.frame.origin.x += 137
                                        self.completionImage.frame.origin.x += 137
                                    }, completion: {finished in
                                        self.actThree()
                                        self.isAct3 = true
                                    })
                                }
                            )}
                        )}
                    )}
                )
            })
            isAct2 = false
        }
        
        if isAct4 == true{
            DispatchQueue.background(background: {
                self.playClickSound()
            })
            UIView.animate(withDuration: 1, animations: {
                self.imageMask.frame.origin.x -= 50
            }, completion: nil)
            
            UIView.animate(withDuration: 1, animations: {
                self.faceImage.frame.origin.x -= 50
                self.completionImage.frame.origin.x -= 50
            }, completion: {finished in
                DispatchQueue.background(background: {
                    self.playSuccessSound()
                })
                UIView.animate(withDuration: 0.01, animations: {
                    self.completionImage.transform = CGAffineTransform(scaleX: 0.5, y: 0.5)
                    self.completionImage.alpha = 1
                }, completion: {finished in
                    UIView.animate(withDuration: 0.5, animations: {
                        self.completionImage.transform = CGAffineTransform(scaleX: 2.7, y: 2.7)
                        self.completionImage.alpha = 0.1
                    }, completion: {finished in
                        UIView.animate(withDuration: 0.01, animations: {
                            self.completionImage.transform = CGAffineTransform(scaleX: 1, y: 1)
                            self.completionImage.alpha = 0
                        }, completion: {finished in
                            })
                        }
                    )}
                ) //
                if self.isComplete1 == true{
                    self.endingAct()
                }
            })
            
            isAct4 = false
            isComplete1 = true
        }
    }
    
   
    
    func actThree(){
        UIView.animate(withDuration: 1, animations: {
            self.imagePart3.frame.origin.y += 100
        }, completion: nil)
        
        UIView.animate(withDuration: 1, animations: {
            self.imageTip3.frame.origin.y -= 320
        }, completion: {finished in
            UIView.animate(withDuration: 1, animations: {
                self.leftHandWash.frame.origin.y -= 150
            }, completion: nil)
        })
        
        UIView.animate(withDuration: 0.1, animations: {
            self.imagePart3.frame.origin.y += 1
        }, completion: { finished in
            UIView.animate(withDuration: 1, delay: 0.3,animations: {
                self.rightHandWash.frame.origin.y -= 150
            }, completion: nil)
        })
    }
    
    @objc func handWashPressed(_ sender: UIButton){
        if isAct3 == true{
            DispatchQueue.background(background: {
                self.playClickSound()
            })
            washingHands()
            isAct3 = false
        }
        
    }
    
    func washingHands(){
            UIView.animate(withDuration: 0.3,animations: {
                self.leftHandWash.frame.origin.x += 15
            }, completion: nil)
            UIView.animate(withDuration: 0.3, animations: {
                self.rightHandWash.frame.origin.x -= 15
            }, completion: {finished in
                UIView.animate(withDuration: 0.3, animations: {
                    self.leftHandWash.frame.origin.x -= 15
                }, completion: nil)
                UIView.animate(withDuration: 0.3, animations: {
                    self.rightHandWash.frame.origin.x += 15
                }, completion: {finished in
                    UIView.animate(withDuration: 0.3,animations: {
                        self.leftHandWash.frame.origin.x += 15
                    }, completion: nil)
                    UIView.animate(withDuration: 0.3, animations: {
                        self.rightHandWash.frame.origin.x -= 15
                    }, completion: {finished in
                        UIView.animate(withDuration: 0.3, animations: {
                            self.leftHandWash.frame.origin.x -= 15
                        }, completion: nil)
                        UIView.animate(withDuration: 0.3, animations: {
                            self.rightHandWash.frame.origin.x += 15
                        }, completion: {finished in
                            UIView.animate(withDuration: 0.3,animations: {
                                self.leftHandWash.frame.origin.x += 15
                            }, completion: nil)
                            UIView.animate(withDuration: 0.3, animations: {
                                self.rightHandWash.frame.origin.x -= 15
                            }, completion: {finished in
                                UIView.animate(withDuration: 0.3, animations: {
                                    self.leftHandWash.frame.origin.x -= 15
                                }, completion: nil)
                                UIView.animate(withDuration: 0.3, animations: {
                                    self.rightHandWash.frame.origin.x += 15
                                }, completion: {finished in
                                    UIView.animate(withDuration: 0.3,animations: {
                                        self.leftHandWash.frame.origin.x += 15
                                    }, completion: nil)
                                    UIView.animate(withDuration: 0.3, animations: {
                                        self.rightHandWash.frame.origin.x -= 15
                                    }, completion: {finished in
                                        UIView.animate(withDuration: 0.3, animations: {
                                            self.leftHandWash.frame.origin.x -= 15
                                        }, completion: nil)
                                        UIView.animate(withDuration: 0.3, animations: {
                                            self.rightHandWash.frame.origin.x += 15
                                        }, completion: {finished in
                                            UIView.animate(withDuration: 0.3,animations: {
                                                self.leftHandWash.frame.origin.x += 15
                                            }, completion: nil)
                                            UIView.animate(withDuration: 0.3, animations: {
                                                self.rightHandWash.frame.origin.x -= 15
                                            }, completion: {finished in
                                                UIView.animate(withDuration: 0.3, animations: {
                                                    self.leftHandWash.frame.origin.x -= 15
                                                }, completion: nil)
                                                UIView.animate(withDuration: 0.3, animations: {
                                                    self.rightHandWash.frame.origin.x += 15
                                                }, completion: {finished in
                                                    UIView.animate(withDuration: 0.3,animations: {
                                                        self.leftHandWash.frame.origin.x += 15
                                                    }, completion: nil)
                                                    UIView.animate(withDuration: 0.3, animations: {
                                                        self.rightHandWash.frame.origin.x -= 15
                                                    }, completion: {finished in
                                                        UIView.animate(withDuration: 0.3, animations: {
                                                            self.leftHandWash.frame.origin.x -= 15
                                                        }, completion: nil)
                                                        UIView.animate(withDuration: 0.3, animations: {
                                                            self.rightHandWash.frame.origin.x += 15
                                                        }, completion: {finished in
                                                            UIView.animate(withDuration: 0.3,animations: {
                                                                self.leftHandWash.frame.origin.x += 15
                                                            }, completion: nil)
                                                            UIView.animate(withDuration: 0.3, animations: {
                                                                self.rightHandWash.frame.origin.x -= 15
                                                            }, completion: {finished in
                                                                UIView.animate(withDuration: 0.3, animations: {
                                                                    self.leftHandWash.frame.origin.x -= 15
                                                                }, completion: nil)
                                                                UIView.animate(withDuration: 0.3, animations: {
                                                                    self.rightHandWash.frame.origin.x += 15
                                                                }, completion: {finished in
                                                                    UIView.animate(withDuration: 0.3,animations: {
                                                                        self.leftHandWash.frame.origin.x += 15
                                                                    }, completion: nil)
                                                                    UIView.animate(withDuration: 0.3, animations: {
                                                                        self.rightHandWash.frame.origin.x -= 15
                                                                    }, completion: {finished in
                                                                        UIView.animate(withDuration: 0.3, animations: {
                                                                            self.leftHandWash.frame.origin.x -= 15
                                                                        }, completion: nil)
                                                                        UIView.animate(withDuration: 0.3, animations: {
                                                                            self.rightHandWash.frame.origin.x += 15
                                                                        }, completion: {finished in
                                                                            DispatchQueue.background(background: {
                                                                                               self.playSuccessSound()
                                                                                           })
                                                                                           UIView.animate(withDuration: 0.01, animations: {
                                                                                               self.completionImage.transform = CGAffineTransform(scaleX: 0.5, y: 0.5)
                                                                                               self.completionImage.alpha = 1
                                                                                           }, completion: {finished in
                                                                                               UIView.animate(withDuration: 0.5, animations: {
                                                                                                   self.completionImage.transform = CGAffineTransform(scaleX: 2.7, y: 2.7)
                                                                                                   self.completionImage.alpha = 0.1
                                                                                               }, completion: {finished in
                                                                                                   UIView.animate(withDuration: 0.01, animations: {
                                                                                                       self.completionImage.transform = CGAffineTransform(scaleX: 1, y: 1)
                                                                                                       self.completionImage.alpha = 0
                                                                                                   }, completion: {finished in
                                                                            
                                                                                       })
                                                                                                   }
                                                                                               )}
                                                                                           ) //
                                                                        })
                                                                    })
                                                                })
                                                            })
                                                        })
                                                    })
                                                })
                                            })
                                        })
                                    })
                                })
                            })
                        })
                    })
                })
            })
        
        UIView.animate(withDuration: 4.5, animations: {
            self.imageBubble.transform = CGAffineTransform(scaleX: 1, y: 1)
            self.imageBubble.alpha = 1
        }, completion: {finished in
            UIView.animate(withDuration: 2, animations: {
                self.imageBubble.transform = CGAffineTransform(scaleX: 0.01, y: 0.01)
                self.imageBubble.alpha = 0
            }, completion: {finished in
                UIView.animate(withDuration: 1, animations: {
                    self.leftHandWash.frame.origin.y += 150
                }, completion: nil)
                UIView.animate(withDuration: 1, delay : 0.2,animations: {
                    self.rightHandWash.frame.origin.y += 150
                }, completion: {finished in
                    UIView.animate(withDuration: 1, animations: {
                        self.imageTip3.frame.origin.y += 320
                    }, completion: nil)
                    UIView.animate(withDuration: 1, animations: {
                        self.imagePart3.frame.origin.y -= 100
                    }, completion: {finished in
                        self.actFour()
                        self.isAct4 = true
                    })
                })
            })
        })
    }
    func actFour(){
        UIView.animate(withDuration: 1, animations: {
            self.imageMask.frame.origin.x -= 274
        }, completion: nil)
        
        UIView.animate(withDuration: 1, animations: {
            self.faceImage.frame.origin.x -= 274
            self.completionImage.frame.origin.x -= 274
        }, completion: {finished in
            UIView.animate(withDuration: 1, animations: {
                self.imageTip4.frame.origin.x += 500
            }, completion: nil)
            UIView.animate(withDuration: 1, animations: {
                self.imagePart4.frame.origin.x -= 570
            }, completion: {finished in
                UIView.animate(withDuration: 1, animations: {
                    self.imagePerson2.frame.origin.x -= 250
                }, completion: {finished in
                    UIView.animate(withDuration: 0.4, animations: {
                        self.imageDistance.transform = CGAffineTransform(scaleX: 1, y: 1)
                    }, completion: nil)
                })
            })
        })
        imagePerson2.addTarget(self, action: #selector(face2Pressed(_:)), for: .touchUpInside)
    }
    
    @objc func face2Pressed(_ sender: UIButton){
        
        
        
    }
    
    func endingAct(){
        
        UIView.animate(withDuration: 1, animations: {
            self.imageDistance.transform = CGAffineTransform(scaleX: 0.01, y: 0.01)
        }, completion: {finished in
            UIView.animate(withDuration: 1, animations: {
                self.imageTip4.frame.origin.x -= 500
            }, completion: nil)
            UIView.animate(withDuration: 1, animations: {
                self.imagePart4.frame.origin.x += 570
            }, completion: {finished in
                UIView.animate(withDuration: 1, animations: {
                    self.imagePerson2.frame.origin.x += 250
                }, completion: {finished in
                    UIView.animate(withDuration: 1, animations: {
                        self.faceImage.frame.origin.x += 187
                        self.completionImage.frame.origin.x += 187
                    }, completion: nil)
                    UIView.animate(withDuration: 1, animations: {
                        self.imageMask.frame.origin.x += 187
                    }, completion: {finished in
                        UIView.animate(withDuration: 1, animations: {
                            self.imageWellDone.transform = CGAffineTransform(scaleX: 1, y: 1)
                        }, completion: {finished in
                            DispatchQueue.background(background: {
                                self.playWinSound()
                            })
                            UIView.animate(withDuration: 1, animations: {
                                self.restartButton.transform = CGAffineTransform(scaleX: 1, y: 1)
                            }, completion: nil)
                        })
                        
                    })
                })
            })
        })
    }
    
    @objc func restartButtonPressed(_ sender: UIButton){
        DispatchQueue.background(background: {
            self.playClickSound()
        })
        UIView.animate(withDuration: 1, animations: {
            self.restartButton.transform = CGAffineTransform(scaleX: 0.01, y: 0.01)
        }, completion: {finished in
            UIView.animate(withDuration: 1, animations: {
                self.imageWellDone.transform = CGAffineTransform(scaleX: 0.01, y: 0.01)
            }, completion: {finished in
                UIView.animate(withDuration: 1, animations: {
                    self.imageMask.frame.origin.y += 250
                }, completion: {finished in
                    UIView.animate(withDuration: 1, animations: {
                        self.titleImage.frame.origin.y += 180
                    }, completion: nil)
                    
                    UIView.animate(withDuration: 1, animations: {
                        self.startButton.frame.origin.y -= 180
                    }, completion:nil)
                })
            })
        })
        
        
        
        
        
    }
    
}
let viewController = MyViewController()
viewController.preferredContentSize = CGSize(width: 640, height: 440)
PlaygroundPage.current.liveView = viewController
//PlaygroundPage.current.needsIndefiniteExecution = true
